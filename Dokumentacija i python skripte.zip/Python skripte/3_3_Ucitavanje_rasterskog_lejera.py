import os

#Učitavanje raster u projekat
#Putanja do rastera (TIF)
put_do_evalacionog_modela = "C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/2. Rasteri/1. Prva grupa kriterijuma/DEMBor.tif"

rlayer = QgsRasterLayer(put_do_evalacionog_modela, "DEMBor")

if not rlayer.isValid():
    print("Lejer nije uspešno učitan.")
else:
    QgsProject.instance().addMapLayer(rlayer)

"""
#Drugi nacin ali mi nećemo da učitavamo dva puta isti raster
    iface.addRasterLayer(put_do_evalacionog_modela, "DEM_Bor")
"""
