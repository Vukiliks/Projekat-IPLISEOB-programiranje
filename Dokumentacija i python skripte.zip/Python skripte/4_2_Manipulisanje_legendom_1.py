root = QgsProject.instance().layerTreeRoot()

granica_bor = QgsProject.instance().mapLayersByName("GranicaBorVezba")[0]

#Kreira "privremeni" lejer
layer1 = QgsVectorLayer("C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/1. Vektorski lejeri/privremeni_lejer", "privremeni_lejer", "memory")

#Dodaje lejer na poslednju poziciju u legendi:
root.addLayer(layer1)

#Dodaje lejer na specificno navedenu poziciju:
#root.insertLayer(3, layer1)

#Moguće je takođe dodati lejer u registar lejera mape, kao sto je rađeno u prethodnim skriptama:
#QgsProject.instance()addMapLayer(layer1)

node_layer = root.findLayer(granica_bor.id())
print("Čvor lejera: ", node_layer)
print("Lejer na mapi: ", node_layer.layer())

#Dodavanje grupa:
node_group1 = root.addGroup("Vektorski lejeri")
node_group2 = root.addGroup("Rasterski lejeri")
#Dodaje podgrupu prethodno kreiranoj grupi:
node_subgroup1 = node_group1.addGroup("Granice")
node_subgroup2 = node_group2.addGroup("DEM")

#Prebacivanje čvorova i grupa:
#Prvo se klonira postojeci čvor:
cloned_group1 = node_group1.clone()
cloned_group2 = node_group2.clone()

#Zatim se pomera čvor (ujedno se pomeraju i lejeri i podgrupe) na vrh.
root.insertChildNode(0, cloned_group1)
root.insertChildNode(0, cloned_group2)

#Uklanjanje originalnog čvora:
root.removeChildNode(node_group1)
root.removeChildNode(node_group2)
