canvas = QgsMapCanvas()
canvas.show()

canvas.setCanvasColor(Qt.white)
canvas.enableAntiAliasing(True)

#Korišćeni lejer = CLCBorVezba
lejer = iface.activeLayer()

if not lejer.isValid():
    print('Lejer nije uspesno ucitan')

#Namešta obim po učitanom lejeru
canvas.setExtent(lejer.extent())

#Podešava lejere za "platno" mape
canvas.setLayers([lejer])