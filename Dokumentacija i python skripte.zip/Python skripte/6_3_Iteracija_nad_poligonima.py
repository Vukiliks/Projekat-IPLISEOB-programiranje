lejer = iface.activeLayer()

#Vrši iteraciju nad podskupom feature-a unutar odredjenog prostora:
clcborvezba = QgsRectangle(7562935,4861888, 7600435,4905644)
request = QgsFeatureRequest().setFilterRect(clcborvezba)

for feature in lejer.getFeatures(request):
    if feature[4] < 15.0:
        print("Povrsina poligona je manja od 15km kvadratnih")
    else:
        print("Povrsina poligona je veca od 15km kvadratnih")

#Moguće je postaviti limit koliko feature-a želimo da bude vraceno:
request.setLimit(2)
for feature in lejer.getFeatures(request):
    print(feature)
    
#Ukoliko želimo da izvršimo iteraciju i filtriranje na osnovu određenog atributa, tu možemo iskoristimo QgsExpression objekat
#i da ga prosledimo QgsFeatureRequest konstruktoru
izraz = QgsExpression("Vrednost > 2")
request = QgsFeatureRequest(izraz)

for feature in lejer.getFeatures(request):
    print(feature[1])
