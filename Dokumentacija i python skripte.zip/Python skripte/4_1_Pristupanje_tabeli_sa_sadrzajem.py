#Daje listu lejera pomoću komprhenzije liste:
l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]

#Rečnik sa key = nazivom lejera i value = objektom lejera
layers_list = {}
for l in QgsProject.instance().mapLayers().values():
  layers_list[l.name()] = l

print(layers_list)
