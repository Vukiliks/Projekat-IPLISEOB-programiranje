'''from qgis.PyQt.QtGui import (
    QColor,
)

from qgis.PyQt.QtCore import Qt, QRectF

from qgis.core import (
    QgsVectorLayer,
    QgsPoint,
    QgsPointXY,
    QgsProject,
    QgsGeometry,
    QgsMapRendererJob,
)

from qgis.gui import (
    QgsMapCanvas,
    QgsVertexMarker,
    QgsMapCanvasItem,
    QgsRubberBand,
)''' #Ukoliko je standalone

canvas = QgsMapCanvas()
canvas.show()

canvas.setCanvasColor(Qt.white)
canvas.enableAntiAliasing(True)

#Korišćeni lejer = CLCBorVezba
lejer = iface.activeLayer()

if not lejer.isValid():
    print("Lejer nije uspesno ucitan")

#Namešta obim po učitanom lejeru
canvas.setExtent(lejer.extent())

#Podešava lejere za "platno" mape
canvas.setLayers([lejer])

linije = QgsRubberBand(canvas, False) #False označava da nije poligon
tacke = [
QgsPoint(7362758, 4935009), 
QgsPoint(7383496, 4935482), 
QgsPoint(7367184, 4934895)
]
linije.setToGeometry(QgsGeometry.fromPolyline(tacke), None)
linije.setWidth(3)
linije.setColor(QColor(255,255,255))

poligon = QgsRubberBand(canvas, True) #True označava da je u pitanju poligon
tacke = [
[QgsPointXY(7367763,4942398), 
QgsPointXY(7373588,4944579), 
QgsPointXY(7370046,4940009)]
]
poligon.setToGeometry(QgsGeometry.fromPolygonXY(tacke), None)
poligon.setColor(QColor(255,0,0))

#Ukoliko želimo da "sakrijemo" odredjeni item
#poligon.hide()

#Ukoliko želimo da prikažemo odredjeni item
#poligon.show()

#Ukoliko želimo da uklonimo lejer iz scene
#canvas.scene().removeItem(tacke)

m = QgsVertexMarker(canvas)
m.setCenter(QgsPointXY(7362758,4935009))

m.setColor(QColor(50,50,200))
m.setIconSize(10)
m.setIconType(QgsVertexMarker.ICON_CIRCLE)
m.setPenWidth(3)