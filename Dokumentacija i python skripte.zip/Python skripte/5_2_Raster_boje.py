raster = QgsProject.instance().mapLayersByName('DEMBor')[0]

#Postavljanje upita za trenutni renderer:
print(raster.renderer())

#Vraća tip rastera:
print(raster.renderer().type())

#Menjanje boje (rendera) za rastere sa jednim kanalom
#Kreiranje skale (objekat QgsColorRampShader):
skala = QgsColorRampShader()

#Biranje tipa skale:
skala.setColorRampType(QgsColorRampShader.Interpolated)

#Kreiranje boja koje ce se koristiti (zuta i zelena):
lista = [QgsColorRampShader.ColorRampItem(0, QColor(0,255,0)),
QgsColorRampShader.ColorRampItem(255, QColor(255,255,0))]

#Dodavanje boja skali:
skala.setColorRampItemList(lista)
shader = QgsRasterShader()
shader.setRasterShaderFunction(skala)

#Povezivanje shader-a sa rasterom, broj 1 ukazuje broj kanala
renderer = QgsSingleBandPseudoColorRenderer(raster.dataProvider(), 1, shader)
raster.setRenderer(renderer)
raster.triggerRepaint()

#Za multispektralni (satelitski snimci npr.) može se koristiti za kreiranje laznog i pravog kolor kompozita
#Primer ispod je za pravi kolor kompozit
raster_multi = QgsProject.instance().mapLayersByName("DEMBor")[0]
raster_multi.renderer().setBlueBand(1)
raster_multi.renderer().setGreenBand(2)
raster_multi.renderer().setRedBand(3)
raster_multi.triggerRepaint()

#Upit za dobijanje vrednosti celije rastera, na osnovu koordinata vraća tuple sa bool-eanskim vrednostima:
val, res = raster_multi.dataProvider().sample(QgsPointXY(7593217, 4896991), 1)

print(val, res)
