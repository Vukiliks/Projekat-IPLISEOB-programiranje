import os
#from qgis.core import(QgsVectorLayer) - ukoliko je u standalone

#Putanja do gpkg:
put_do_opstine = os.path.join(QgsApplication.pkgDataPath(), "resources", "data", "C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/1. Vektorski lejeri/OpstineRS.gpkg")

vlayer = QgsVectorLayer(put_do_opstine, "OpstineRS", "ogr")

if not vlayer.isValid():
    print("Lejer nije uspesno ucitan")
else:
    QgsProject.instance().addMapLayer(vlayer)
