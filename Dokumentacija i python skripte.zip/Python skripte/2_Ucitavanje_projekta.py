#Ukoliko se skripta pokrece izvan QGIS-a, potrebno je importovati qgis i PyQT klase koje ce se koristiti
#from qgis.core import QgisProject as QgsProject

#Instanciranje projekta:
project = QgsProject.instance()

#Učitavanje projekta:
project.read ("C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/Projekat IPLISEOB.qgz")

# Ako u projektu dođe do izmene, uvek možemo to sačuvati pod istim imenom:
project.write()

#Ili pod različitim, ali to nećemo zato ovaj deo koda ide pod komentar.
#project.write ("C:/Users/HP/Desktop/GIS programiranje - projekat/Vukašin/Projekat_programiranje_drugi_naziv.qgz")

#Menja loše "putanje", u slučaju da je doslo do promene lokacije lejera, promene adrese od hosta ili baze podataka.

def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)
