# from qgis.core import QgsMarkerSymbolLayer
# from qgis.PyQt.QtGui import QColor
# from qgis.gui import QgsSymbolWidget
# from qgis.core import QgsSymbol, QgsSymbolLayerAbstractMetadata, QgsSymbolLayerRegistry

'''Kreira novi simbol lejer'''

lejer = iface.activeLayer()

class FooSymbolLayer(QgsMarkerSymbolLayer):
    def __init__(self, radius=4.0):
        QgsMarkerSymbolLayer.__init__(self)
        self.radius = radius
        self.color = QColor(0,255,0)
    
    def layerType(self):
        return "FooMarker"
    
    def properties(self):
        return {"radius" : str(self.radius)}
        
    def startRender(self, context):
        pass
    
    def stopRender(self, context):
        pass
    
    def renderPoint(self, point, context):
        #Renderovanje zavisi od toga da li je simbol izabran
        boja = context.selectionColor() if context.selected() else self.color
        p = context.renderContext().painter()
        p.setPen(boja)
        p.drawEllipse(point, self.radius, self.radius)
    
    def clone(self):
        return FooSymbolLayer(self.radius)


class FooSymbolLayerWidget(QgsSymbolLayerWidget):
    def __init__(self, parent=None):
        QgsSymbolLayerWidget.__init__(self, parent)
        self.layer = None
        
        #Postavljanje grafičkog interfejsa
        self.label = QLabel("Radius: ")
        self.spinRadius = QDoubleSpinBox()
        self.hbox = QHBoxLayout()
        self.hbox.addWidget(self.label)
        self.hbox.addWidget(self.spinRadius)
        self.setLayout(self.hbox)
        self.connect(
        self.spinRadius,
        SIGNAL("valueChanged(double)"),
        self.radiusChanged
        )
    
    def setSymbolLayer(self, layer):
        if layer.layerType() != "FooMarker":
            return
        self.layer = layer
        self.spinRadius.setValue(layer.radius)
    
    def symbolLayer(self):
        return self.layer
    
    def radiusChanged(self, value):
        self.layer.radius = value
        self.emit(SIGNAL("changed()"))
        

class FooSymbolLayerMetadata(QgsSymbolLayerAbstractMetadata):

    def __init__(self):
        super().__init__("FooMarker", "Moj novi Foo marker", QgsSymbol.Marker)
    
    def createSymbolLayer(self, props):
        radius = float(props["radius"]) if "radius" in props else 4.0
        return FooSymbolLayer(radius)

simbol = FooSymbolLayer()

print(simbol.layerType())

fslmetapodaci = FooSymbolLayerMetadata()
QgsApplication.symbolLayerRegistry().addSymbolLayerType(fslmetapodaci)
