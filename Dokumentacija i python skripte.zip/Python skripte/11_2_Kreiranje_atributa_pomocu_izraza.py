#from qgis.PyQt.QtCore import QVariant     #Ukoliko je standalone

lejer = QgsVectorLayer('Point?crs=epsg:6316', "Naselja", 'memory')
pr = lejer.dataProvider()
pr.addAttributes([QgsField("Naziv", QVariant.String), QgsField("br_st", QVariant.Int), QgsField("nm_visina", QVariant.Int)])

podaci = [{'x': 7588489, 'y':4881671, 'ime': "Bor", "stanovnici": 15800, "visina": 380},
{'x': 7588076, 'y':4877593, 'ime': "Brestovac", "stanovnici": 10250, "visina": 270},
{'x': 7579447, 'y':4874321, 'ime': "Zlot", "stanovnici": 6300, 'visina': 260}
          ]

for podatak in podaci:
    f = QgsFeature()
    tacka = QgsPointXY(podatak['x'], podatak['y'])
    f.setGeometry(QgsGeometry.fromPointXY(tacka))
    f.setAttributes([podatak['ime'], podatak['stanovnici'], podatak['visina']])
    pr.addFeature(f)

lejer.updateExtents()
QgsProject.instance().addMapLayer(lejer)

#Prvi izraz računa ukupan broj stanovnika
#Drugi izraz kreira bafer zonu oko tačaka, na osnovu nadmorske visine
izraz1 = QgsExpression('sum("br_stanovnika")')
izraz2 = QgsExpression('area($geometry, "nm_visina"))')

# QgsExpressionContextUtils.globalProjectLayerScopes() je funkcija koja nam pomaže da dodamo globalni obim (scope), projekat, i lejere (unutar tog obima) u isto vreme
#Alternativno, oni se mogu ručno dodavati. Važno zapamtiti, uvek se kreće od najopštijeg do najspecifičnijeg obimu (npr. od gobalnog, ka projektu, ka lejerima)

context = QgsExpressionContext()
context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lejer))

with edit(lejer):
    for f in lejer.getFeatures():
        context.setFeature(f)
        f["ukupno_stan"] = izraz1.evaluate(context)
        lejer.updateFeature(f)

print(f['ukupno_stan'])

print('------------------------------')

#Prilikom izvršavanja izraz ili njegovog raščljanjivanja može doći do grešaka, pa je korisno isprobati i videti da li je sve u redu
#ukoliko nije, Pajton ce u ovom slučaju prijaviti da postoji greška
#izraz = QgsExpression('1+1=2')
#if exp.hasParserError():
    #raise Exception(exp.parserErrorString())

#vrednost = exp.evaluate()
#if vrednost.hasEvalError():
    #raise ValueError(exp.evalErrorString())