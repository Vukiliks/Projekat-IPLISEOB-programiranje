#Pozicioniranje rastera na tačnu poziciju

put_do_evalacionog_modela = "C:/Users/Kotrlja/Desktop/GIS programiranje - projekat/Vukašin/Projekat/2. Rasteri/1. Prva grupa kriterijuma/DEMBor.tif"

#Format je - rlayer = QgsVectorLayer(data_source, layer_name)
rlayer = QgsRasterLayer(put_do_evalacionog_modela, "DEMBor")

#Prvo se dodaje lejer, bez "pokazivanja"
QgsProject.instance().addMapLayer(rlayer, False)
#Pristupa se "stablu" lejera koji je na vrhu projekta
layerTree = iface.layerTreeCanvasBridge().rootGroup()
#Pozicija se definise kao prvi argument (-1, za poslednje mesto)
layerTree.insertChildNode(-1, QgsLayerTreeLayer(rlayer))


#Ukoliko želimo da uklonimo lejer:
#QgsProject.instance().removeMapLayer(rlayer.id())

#Ukoliko želimo da izlistamo učitane lejere i njihove ID-e:
#QgsProject.instance().mapLayers()
