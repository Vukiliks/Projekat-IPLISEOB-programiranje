#Pristupanje root-u u legendi (TOC-u) i manipulisanje lejerima u njoj, Instanciranje root-a (pocetnog čvora) od lejera u legendi (TOC-u)
#Root je grupni čvor i ima "decu"
root = QgsProject.instance().layerTreeRoot()
root.children()

dete0 = root.children()[0]
print(dete0)

#Lejerima se takođe moze pristupiti pomocu unikatnog ID-ja:
ids = root.findLayerIds()
x = root.findLayer(ids[0])
print(x)

#Takođe, grupe isto mogu da se pretrazuju pomocu naziva
root.findGroup("DEM")

#Izbacuje listu svih lejera koji su "stiklirani"
postojeci_lejeri = root.checkedLayers()
print(postojeci_lejeri)
