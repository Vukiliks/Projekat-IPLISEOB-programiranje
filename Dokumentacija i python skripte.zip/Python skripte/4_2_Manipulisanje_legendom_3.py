root = QgsProject.instance().layerTreeRoot()
granica = QgsProject.instance().mapLayersByName("GranicaBorVežba")[0]

#Pomeranje lejera u legendi
#Kreiranje objekta QgsLayerTreeLayer iz granica po njegovom ID-u
granicavektor = root.findLayer(granica.id())

#Klonira se prethodno kreirani objekat
granicavektorklon = granica.clone()

#Uzima "roditelja". Ukoliko je rezultat None, znaci da lejer nije ni u jednog grupi i vratiće:''
roditelj = granicavektor.parent()

#Pomera se klonirani lejer na vrh:
roditelj.insertChildNode(0, granicavektorklon)

#Uklanja se originalni lejer (zpdvektor):
root.removeChildNode(granicavektor)

#Prebacivanje lejera u određenu grupu (sličan postupak kao kod pomeranja):
granicavektor = root.findLayer(granica.id())
granicavektorklon = granicavektor.clone()

#Kreiranje nove grupe:
grupa1 = root.addGroup("Granice 2")
roditelj = granicavektor.parent()
grupa1.insertChildNode(0, granicavektorklon)
roditelj.removeChildNode(granicavektor)
