import os #potrebno i u QGIS-u
#from qgis.core import (QgsVectorLayer) - potrebno u ako je u standalone

#Komanda koja uzima lejer na toj lokaciji:

putanja_granica_opstine = "C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/1. Vektorski lejeri/GranicaBorVezba.shp"

#Format komande:
#vlayer = QgsVectorLayer(data_source, layer_name, provider_name)

vlayer = QgsVectorLayer(putanja_granica_opstine, "GranicaBorVežba", "ogr")

#Proverava da li je lejer uspešno učitan:

if not vlayer.isValid():
    print('Lejer nije uspešno učitan')
else:
    QgsProject.instance().addMapLayer(vlayer)
