from functools import partial
'''from qgis.core import (QgsTaskManager, QgsMessageLog,
                       QgsProcessingAlgRunnerTask, QgsApplication,
                       QgsProcessingContext, QgsProcessingFeedback,
                       QgsProject)'''  #Ukoliko je standalone
                       
#Kreira 5000 nasumično rasporedjenih tačaka unutar izabranog lejera

lejer = QgsProject.instance().mapLayersByName("GranicaBorVezba")[0]
MESSAGE_CATEGORY = 'AlgRunnerTask'

def task_zavrsen(context, uspesno, results):
    if not uspesno:
        QgsMessageLog.logMessage('Task nije izvrsen', MESAGE_CATEGORY, Qgis.Warning)
    
    #takeMapLejer prebacuje vlasništvo nad lejerom, 
    #pa je onda moguće dodati ga u projekat i dodeliti mu
    #vlašnistvo od projekta. U suprotnom, došlo bi do pucanja programa
    izlazni_lejer = context.getMapLayer(results['OUTPUT'])
    if izlazni_lejer and izlazni_lejer.isValid():
        QgsProject.instance().addMapLayer(context.takeResultLayer(izlazni_lejer.id()))

algoritam = QgsApplication.processingRegistry().algorithmById('qgis:randompointsinlayerbounds')
context = QgsProcessingContext()
feedback = QgsProcessingFeedback()
parametri = {
'INPUT': lejer,
'POINTS_NUMBER': 5000,
'TARGET_CRS': 'EPSG:6316',
'OUTPUT': 'memory:RandomTacke'
}

task = QgsProcessingAlgRunnerTask(algoritam, parametri, context, feedback)
task.executed.connect(partial(task_zavrsen, context))
QgsApplication.taskManager().addTask(task)