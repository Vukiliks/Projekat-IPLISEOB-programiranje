import os

#Skripta ne radi najbolje, ima problema sa renderovanjem mape i učitavanjem odredjenih itema (razmernika, oznake za sever...)

projekat = QgsProject.instance()
layout = QgsPrintLayout(projekat)

#Ukoliko kreiramo novi layout(dizajn) za štampanje, korisno je izvršiti inicijalizaciju default podešavanja, cime kreiramo prazan A4 list

layout.initializeDefaults()
layout.setName("Layout_py")
projekat.layoutManager().addLayout(layout)

#Kreiranje mape
mapa = QgsLayoutItemMap(layout)

#Podešava poziciju i veličinu mape (default vrednosti su 0 za širinu i visinu i postavljena je na 0,0)
mapa.attemptMove(QgsLayoutPoint(5,10, QgsUnitTypes.LayoutMillimeters))
mapa.attemptResize(QgsLayoutSize(200, 160, QgsUnitTypes.LayoutMillimeters))

#Definiše obim koji ce se renderovati
mapa.zoomToExtent(iface.mapCanvas().extent())
layout.addLayoutItem(mapa)

#Kreiranje labela
label = QgsLayoutItemLabel(layout)
label.setText("Karta")
label.adjustSizeToText()
layout.addLayoutItem(label)

#Kreiranje legende
legenda = QgsLayoutItemLegend(layout)
legenda.setLinkedMap(mapa) #instanca od QgsLayoutItemMap
layout.addLayoutItem(legenda)

#Kreiranje razmernika
razmernik = QgsLayoutItemScaleBar(layout)
razmernik.setStyle('Double Box')
razmernik.setLinkedMap(mapa)
razmernik.applyDefaultSize()
layout.addLayoutItem(razmernik)

#Kreiranje oznake za sever
strelica = QgsLayoutItemPicture(layout)
strelica.setPicturePath('"C:/Users/Kotrlja/Desktop/Ispit iz projekata -IPLISEOB/qGIS/2. Rasteri/north-arrow-2')
layout.addLayoutItem(strelica)

label.attemptMove(QgsLayoutPoint(150,1.5, QgsUnitTypes.LayoutMillimeters))
legenda.attemptMove(QgsLayoutPoint(250, 5, QgsUnitTypes.LayoutMillimeters))
razmernik.attemptMove(QgsLayoutPoint(60, 190, QgsUnitTypes.LayoutMillimeters))


#Ukoliko želimo da exportujemo kartu u PDF formatu
#base_path = os.path.join(QgsProject.instance().homePath())
#pdf_path = os.path.join(base_path, 'izlaz.pdf')

#exporter = QgsLayoutExporter(layout)
#exporter.exportToPdf(pdf_path, QgsLayoutExporter.PdfExportSettings())
