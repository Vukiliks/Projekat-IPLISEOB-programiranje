#Potrebno obeležiti lejer u legendi, mora da bude vektor

lejer = iface.activeLayer()
#Selektuje sve feature od lejera
#lejer.selectAll()

#Selektuje feature-e na osnovu odredjenog izraza
#Razlikuje se od lejera na kom se koristi (u ovom slucaju BaferZPDVezba)
#Prvi argument predstavlja izraz, na osnovu kog se vrsi upit
lejer.selectByExpression('"Vrednost"> 2 and "Povrsina" > 4', QgsVectorLayer.SetSelection)

#Menja boju selekcije (default je žuta)
iface.mapCanvas().setSelectionColor(QColor("green"))

#Briše selektovane feature
#lejer.removeSelection()

#selected_fid = []

#Uzima prvi feature id iz lejera
'''for feature in lejer.getFeatures():
    selected_fid.append(feature.id())
    break'''

#Dodaje ove feature selektovanoj listi
#lejer.select(selected_fid)

#lejer.removeSelection()

#Atributima se moze pristupiti na osnovu imena ili indeksa:
print(feature["Vrednost"])
print(feature[1])

#Ukoliko su nam potrebni samo selektovani feature-i
selekcija = lejer.selectedFeatures()
for feature in selekcija:
    if feature["povrsina"] < 20:
        print('Povrsina je manja od 20km kvadratnih')
    else:
        print('Povrsina je veca od 20km kvadratnih')
