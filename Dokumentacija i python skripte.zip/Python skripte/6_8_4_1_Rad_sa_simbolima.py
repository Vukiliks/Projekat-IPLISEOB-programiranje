# from qgis.core import QgsSymbolLayerRegistry - ukoliko je standalone

#Štampa koje sve tipove simbol lejera možemo da kreiramo za datu klasu simbola
#klasa QgsSymbolLayerRegistry upravlja bazom podataka u kojoj se nalaze svi mogući tipovi simbola

registar = QgsApplication.symbolLayerRegistry()
metapodaci = registar.symbolLayerMetadata("SimpleFill")
for item in registar.symbolLayersForType(QgsSymbol.Marker):
    print(item)

simbol = QgsMarkerSymbol()
simbol.properties()
