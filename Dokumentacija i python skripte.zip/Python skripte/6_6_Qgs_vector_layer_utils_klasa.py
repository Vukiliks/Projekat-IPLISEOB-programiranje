# klasa QgsVectorLayerUtils
#Sadrži odredjene, korisne metode 

#Priprema QgsFeature objekat da bude dodat lejeru zadržavajući sva ograničenja i default vrednosti
#korišćeni atribut 
lejer = iface.activeLayer()
feat = QgsVectorLayerUtils.createFeature(lejer)

# getValues metod omogucava dobijanje vrednosti
#Za odredjeni atribut ili izraz
lejer.selectByIds([0])
value = QgsVectorLayerUtils.getValues(lejer, "CLCBorVezba", selectedOnly=True)
print(value)
