'''from qgis.core import(
    QgsRasterLayer,
    QgsProject,
    QgsPointXY,
    QgsRaster,
    QgsRasterShader,
    QgsColorRampShader,
    QgsSingleBandPseudoColorRenderer,
    QgsSingleBandColorDataRenderer,
    QgsSingleBandGrayRenderer,
    )

from qgis.PyQt.QtGui import (
    QColor,
    )'''

raster = QgsProject.instance().mapLayersByName("DEMBor")[0]

#Vraća rezoluciju rastera:
print(raster.width(), raster.height())

#Vraća x i y koordinate rastera kao stringove:
print(raster.extent().toString())

#Vraća tip raster: 0 = grayscale (1 kanal), 1 = paleta (1 kanal)
#2 = vise kanala (multiband)
print(raster.rasterType())

#Vraća broj kanala od rastera (za multispektralne snimke bi bilo više)
print(raster.bandCount())

#Vraća naziv prvog spektralnog kanala od rastera
print(raster.bandName(1))

#Vraća metapodatke od rastera kao QgsLayerMetadata objekat
print(raster.metadata())
