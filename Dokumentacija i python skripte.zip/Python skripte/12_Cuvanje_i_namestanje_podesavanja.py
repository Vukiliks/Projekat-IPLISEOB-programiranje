'''from qgis.core import (
  QgsProject,
  QgsSettings,
  QgsVectorLayer
)'''             #Ukoliko je standaloneDayName

#Čuva podešavanja na globalnom nivou (vezano za korisnika koji koristi kompjuter)
# npr: veličina glavnog prozora..

s = QgsSettings()
#print(s.allKeys())

def sacuvaj():
    s = QgsSettings()
    s.setValue("moj_plugin/moj_tekst", "GIS programiranje")
    s.setValue("moj_plugin/moj_celobrojni",  7)
    s.setValue("moj_plugin/moj_realni", 1.61)
    s.setValue("qgis/digitizing/default_snapping_tolerance_unit", "snepovanje", 2)
    
def procitaj():
    s = QgsSettings()
    moj_tekst = s.value("moj_plugin/moj_tekst", "GIS Programiranje")
    moj_celobrojni  = s.value("moj_plugin/moj_celobrojni", 7)
    moj_realni = s.value("moj_plugin/moj_realni", 1.61)
    nepostojeci = s.value("moj_plugin/nepostojeci", None)
    print(moj_tekst)
    print(moj_celobrojni)
    print(moj_realni)
    print(nepostojeci)
    
sacuvaj()
procitaj()


projekat = QgsProject.instance()

#Čuva vrednosti
projekat.writeEntry("moj_plugin", "moj_tekst", "GIS Prog")
projekat.writeEntry("moj_plugin", "moj_celobrojni", 7)
projekat.writeEntryDouble("moj_plugin", "moj_realni", 1.61)
projekat.writeEntryBool("moj_plugin", "moja_bulova_algebra", True)

#Čita vrednosti (vraća torku sa vrednostima, i Bulov status
#koji govori da li se vraćena vrednost može konvertovati u njen tip,
#odnosno iz stringa, celobrojnog broja, realnog broja i Bulovog izraza

moj_tekst, type_conversion_ok = projekat.readEntry("moj_plugin", "moj_tekst", "GIS Prog")
moj_celobrojni, type_conversion_ok = projekat.readNumEntry("moj_plugin", "moj_celobrojni", 7)
moj_realni, type_conversion_ok = projekat.readDoubleEntry("moj_plugin", "moj_realni", 1.61)
moja_bulova_algebra, type_conversion_ok = projekat.readBoolEntry("moj_plugin", "moja_bulova_algebra", True)

lejer = QgsProject.instance().mapLayersByName("NaseljaBorVezba")[0]
#Čuva vrednost za odredjeni lejer

lejer.setCustomProperty('moj_tekst', "Borska naselja")
#Ponovo čita vrednost; drugi argument vraca

tekst = lejer.customProperty('moj_tekst', 'nema_teksta')

print('-----------------------------------------')
print(tekst)